# 🌍 Aiutopia - AI-Powered Causal Intelligence Platform

[![Live Demo](https://img.shields.io/badge/demo-live-success)](#)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Made with Love](https://img.shields.io/badge/made%20with-❤️-red.svg)](#)

> Transform data into causal insights with AI-powered analysis. Make better decisions backed by science, not just correlations.

## ✨ Features

- 🧠 **AI-Powered Causal Analysis** - Uses advanced LLMs to discover true cause-and-effect relationships
- 📊 **Multiple Data Sources** - Stock market, weather, business data, and custom CSV uploads
- 🎯 **Actionable Recommendations** - Get specific interventions with confidence levels and ROI estimates
- 📈 **Real-Time Intelligence** - Live stock analysis, weather impacts, and business correlations
- 🌐 **Beautiful Web Interface** - Professional, responsive UI that works on any device
- 💰 **100% Free** - Powered by free API tiers (15,900 daily requests)

## 🎬 Demo

Open `index.html` in your browser to try it locally!

## 🚀 Quick Start

### Web Version (No Installation)

1. Visit the live demo
2. Enter your data or use quick examples
3. Click "Analyze with AI"
4. Get causal insights instantly!

### Local Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/aiutopia.git
cd aiutopia

# Install dependencies
pip install -r requirements.txt

# Set up API keys
cp .env.example .env
# Edit .env and add your API keys (see below)

# Run the Python version
python3 aiutopia_ultimate.py

# Or open the web version
open index.html
```

## 🔑 API Keys (Optional - Get Free Keys)

Aiutopia works with free API tiers. Get your free keys here:

| Service | Free Tier | Get Your Key |
|---------|-----------|--------------|
| **Groq AI** | 14,400 requests/day | [console.groq.com](https://console.groq.com) |
| **Alpha Vantage** | 500 requests/day | [alphavantage.co](https://www.alphavantage.co/support/#api-key) |
| **OpenWeather** | 1,000 requests/day | [openweathermap.org](https://openweathermap.org/api) |

**Total: 15,900 free API calls per day!**

After getting keys, add them to `.env` file:
```bash
GROQ_API_KEY=your_key_here
ALPHA_VANTAGE_KEY=your_key_here
OPENWEATHER_KEY=your_key_here
```

## 📖 How It Works

### The Problem
Most analytics tools show correlations, not causality. Just because two things move together doesn't mean one causes the other.

### The Solution
Aiutopia uses:
1. **Causal Inference AI** - Identifies true cause-and-effect relationships
2. **Multi-Source Analysis** - Combines business, weather, and market data
3. **Confidence Scoring** - Every insight includes reliability metrics
4. **Intervention Design** - Recommends specific actions with expected outcomes

### Example Use Cases

**🏪 Retail Business**
- Input: Sales data + weather patterns
- Output: "Rain decreases foot traffic by 23% but increases online orders by 31%"
- Action: Run rain-day promotions, adjust staffing

**💼 SaaS Company**
- Input: Feature usage + churn data
- Output: "Users with 6+ features have 89% lower churn"
- Action: Implement feature discovery program

**📈 Stock Trading**
- Input: Stock symbol (e.g., AAPL)
- Output: Volume patterns, support/resistance levels, causal drivers
- Action: Data-driven entry/exit points

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **AI/ML**: Groq API (Llama 3.1 70B), Custom causal inference algorithms
- **Data**: Alpha Vantage (stocks), OpenWeather (weather), World Bank (economics)
- **Backend**: Python 3.8+, FastAPI (optional)
- **Deployment**: Static hosting (Netlify, GitHub Pages, Vercel)

## 📁 Project Structure

```
aiutopia/
├── index.html                    # Web interface (standalone)
├── aiutopia_ultimate.py         # Python CLI with all features
├── aiutopia_simple.py           # Python CLI basic version
├── aiutopia_full.py             # Python CLI with stock analysis
├── aiutopia_backend.py          # FastAPI server (optional)
├── test_aiutopia.py             # Test script
├── setup_aiutopia.sh            # Auto-setup (Mac/Linux)
├── setup_aiutopia.bat           # Auto-setup (Windows)
├── requirements.txt             # Python dependencies
├── .env.example                 # API key template
└── README.md                    # This file
```

## 💡 Usage Examples

### Python CLI

```bash
python3 aiutopia_ultimate.py
```

Choose from 7 analysis modes:
1. Your CSV data
2. Describe your data
3. Stock market analysis
4. Weather impact analysis
5. Weather + Business correlation
6. City intelligence
7. Demo

### Web Interface

Simply open `index.html` in your browser or visit the live demo.

## 🤝 Contributing

Contributions are welcome! Here's how:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📊 Roadmap

- [x] Web interface with demo mode
- [x] Python CLI with all features
- [x] Stock market analysis
- [x] Weather + business correlation
- [ ] Real-time dashboard
- [ ] Database integration
- [ ] A/B test evaluation
- [ ] Custom model training
- [ ] Mobile app

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with [Groq](https://groq.com) for ultra-fast AI inference
- Stock data from [Alpha Vantage](https://www.alphavantage.co)
- Weather data from [OpenWeather](https://openweathermap.org)
- Inspired by cutting-edge causal inference research

## 📧 Contact

Open an issue on GitHub for questions or bug reports.

## ⭐ Star History

If you find this project useful, please consider giving it a star!

---

**Made with ❤️ and AI - Changing the world, one decision at a time.**
