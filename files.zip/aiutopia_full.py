"""
AIUTOPIA FULL - With Financial Data Integration
Now with Groq AI + Alpha Vantage stock data!
"""

import os
from dotenv import load_dotenv

load_dotenv()

def analyze_data():
    """Main analysis function"""
    
    print("\n" + "="*70)
    print("🌍 AIUTOPIA - CAUSAL INTELLIGENCE PLATFORM")
    print("   Powered by Groq AI + Alpha Vantage")
    print("="*70 + "\n")
    
    # Check API keys
    groq_key = os.getenv('GROQ_API_KEY')
    av_key = os.getenv('ALPHA_VANTAGE_KEY')
    
    if not groq_key or groq_key == 'paste_your_key_here':
        print("❌ ERROR: GROQ API key not configured")
        return
    
    print("✅ Groq AI: Connected")
    
    if av_key:
        print("✅ Alpha Vantage: Connected (Financial data available!)")
    else:
        print("⚠️  Alpha Vantage: Not configured (optional)")
    
    print()
    
    # Menu
    print("📊 WHAT WOULD YOU LIKE TO ANALYZE?")
    print()
    print("  1 = Your own CSV data")
    print("  2 = Describe your data")
    print("  3 = Analyze stock market data (uses Alpha Vantage)")
    print("  4 = Demo: Marketing → Revenue analysis")
    print()
    
    choice = input("Choose option (1-4): ").strip()
    print()
    
    if choice == "3":
        if not av_key:
            print("❌ Alpha Vantage key needed for stock analysis")
            print("   Get free key at: https://www.alphavantage.co")
            return
        
        analyze_stocks()
        return
    
    elif choice == "4":
        run_demo()
        return
    
    elif choice == "1":
        print("📋 PASTE YOUR CSV DATA:")
        print("(Example: date,sales,marketing)")
        print("(Press Enter twice when done)")
        print()
        
        lines = []
        while True:
            try:
                line = input()
                if not line:
                    break
                lines.append(line)
            except EOFError:
                break
        
        data = "\n".join(lines)
        
    else:  # choice == "2"
        print("📝 DESCRIBE YOUR DATA:")
        print()
        data = input("> ")
    
    if not data.strip():
        print("\n❌ No data provided")
        return
    
    # Analyze with Groq
    analyze_with_groq(data)


def analyze_stocks():
    """Analyze stock market data"""
    
    print("📈 STOCK MARKET CAUSAL ANALYSIS")
    print()
    print("I'll fetch real stock data and analyze causal relationships!")
    print()
    
    symbol = input("Enter stock symbol (e.g., AAPL, TSLA, SPY): ").strip().upper()
    
    if not symbol:
        symbol = "SPY"  # Default to S&P 500
    
    print(f"\n🔍 Fetching {symbol} data from Alpha Vantage...")
    print()
    
    try:
        import requests
        av_key = os.getenv('ALPHA_VANTAGE_KEY')
        
        url = "https://www.alphavantage.co/query"
        params = {
            'function': 'TIME_SERIES_DAILY',
            'symbol': symbol,
            'apikey': av_key,
            'outputsize': 'compact'
        }
        
        response = requests.get(url, params=params, timeout=10)
        data = response.json()
        
        if 'Time Series (Daily)' not in data:
            print(f"❌ Could not fetch data for {symbol}")
            if 'Note' in data:
                print(f"   API limit reached. Wait 1 minute and try again.")
            return
        
        time_series = data['Time Series (Daily)']
        
        # Get recent prices
        dates = sorted(time_series.keys(), reverse=True)[:30]
        prices = [float(time_series[date]['4. close']) for date in dates]
        volumes = [int(time_series[date]['5. volume']) for date in dates]
        
        print(f"✅ Fetched 30 days of {symbol} data")
        print(f"   Latest price: ${prices[0]:.2f}")
        print(f"   Price range: ${min(prices):.2f} - ${max(prices):.2f}")
        print()
        
        # Prepare summary for AI analysis
        summary = f"""
Stock: {symbol}
Period: Last 30 days
Latest Close: ${prices[0]:.2f}
Average Price: ${sum(prices)/len(prices):.2f}
Price Volatility: {((max(prices)-min(prices))/min(prices)*100):.1f}%
Average Volume: {sum(volumes)/len(volumes):,.0f}

Recent price movements:
Week 1: ${prices[0]:.2f}
Week 2: ${prices[7]:.2f}
Week 3: ${prices[14]:.2f}
Week 4: ${prices[21]:.2f}

Analyze causal factors driving price movements and predict future trends.
"""
        
        analyze_with_groq(summary, is_financial=True)
        
    except ImportError:
        print("⚠️  'requests' package needed")
        print("   Run: pip install requests")
    except Exception as e:
        print(f"❌ Error: {str(e)}")


def run_demo():
    """Run demo analysis"""
    
    print("🎬 RUNNING DEMO ANALYSIS")
    print()
    
    demo_data = """
Marketing Campaign Data (6 months):

Month 1: Marketing Spend $10,000 → 42 customers → $25,000 revenue
Month 2: Marketing Spend $12,000 → 51 customers → $30,000 revenue  
Month 3: Marketing Spend $11,000 → 45 customers → $27,000 revenue
Month 4: Marketing Spend $15,000 → 68 customers → $38,000 revenue
Month 5: Marketing Spend $13,000 → 55 customers → $32,000 revenue
Month 6: Marketing Spend $14,000 → 62 customers → $35,000 revenue

Question: What drives revenue growth?
"""
    
    print(demo_data)
    print()
    
    analyze_with_groq(demo_data)


def analyze_with_groq(data, is_financial=False):
    """Analyze data using Groq AI"""
    
    print("="*70)
    print("🔍 ANALYZING WITH GROQ AI...")
    print("="*70 + "\n")
    
    try:
        from groq import Groq
        client = Groq(api_key=os.getenv('GROQ_API_KEY'))
        
        if is_financial:
            prompt = f"""Analyze this stock market data for causal factors:

{data}

Provide:

1. CAUSAL FACTORS
   - What drives price movements?
   - Key indicators and their effects
   
2. TREND ANALYSIS  
   - Short-term trends (1-2 weeks)
   - Medium-term outlook (1-3 months)
   
3. TRADING INSIGHTS
   - Support/resistance levels
   - Risk factors to watch
   - Confidence in analysis

Be specific and data-driven."""
        
        else:
            prompt = f"""Analyze this data for causal relationships:

{data}

Provide:

1. CAUSAL RELATIONSHIPS FOUND
   - Each cause → effect relationship
   - Effect strength and confidence
   
2. RECOMMENDED INTERVENTIONS
   - Specific actions to take
   - Expected impact
   - Priority ranking
   
3. KEY ASSUMPTIONS
   - What this relies on
   - How to validate

Be clear, specific, and actionable."""
        
        response = client.chat.completions.create(
            model="llama-3.1-70b-versatile",
            messages=[
                {
                    "role": "system",
                    "content": "You are a world-class causal inference expert. Provide specific, actionable insights with confidence levels."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0.7,
            max_tokens=2000
        )
        
        analysis = response.choices[0].message.content
        
        # Display results
        print("="*70)
        print("🎯 CAUSAL ANALYSIS RESULTS")
        print("="*70)
        print()
        print(analysis)
        print()
        print("="*70)
        
        # Save to file
        filename = "aiutopia_results.txt"
        with open(filename, 'w') as f:
            f.write("AIUTOPIA CAUSAL ANALYSIS RESULTS\n")
            f.write("="*70 + "\n\n")
            f.write("INPUT DATA:\n")
            f.write(data + "\n\n")
            f.write("="*70 + "\n\n")
            f.write("ANALYSIS:\n")
            f.write(analysis + "\n")
        
        print(f"\n💾 Results saved to: {filename}")
        print()
        
    except ImportError:
        print("⚠️  Groq package not installed")
        print("   Run setup script first!")
    except Exception as e:
        print(f"❌ Error: {str(e)}")


if __name__ == "__main__":
    analyze_data()
